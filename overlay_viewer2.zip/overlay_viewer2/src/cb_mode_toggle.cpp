// cb_mode_toggle.cpp
#include "cb_mode_toggle.h"

#include <vtkCamera.h>
#include <vtkProp.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkTextActor.h>
#include <vtkInteractorStyle.h>

vtkStandardNewMacro(ModeToggleCallback);

void ModeToggleCallback::Add2DProp(vtkProp* p){ if(p) Props2D.push_back(p); }
void ModeToggleCallback::Add3DProp(vtkProp* p){ if(p) Props3D.push_back(p); }

void ModeToggleCallback::SetPropsVisible(const std::vector<vtkProp*>& props, bool vis){
  for(auto* p: props){ if(p) p->SetVisibility(vis?1:0); }
}

void ModeToggleCallback::Save2DCamera(){
  if(!Renderer) return;
  auto cam = Renderer->GetActiveCamera();
  if(!cam) return;
  cam->GetPosition(Cam2D_Pos);
  cam->GetFocalPoint(Cam2D_Focal);
  cam->GetViewUp(Cam2D_ViewUp);
  cam->GetClippingRange(Cam2D_Clipping);
  Cam2D_ParallelScale = cam->GetParallelScale();
  HasSavedCam2D = true;
}

void ModeToggleCallback::Restore2DCamera(){
  if(!Renderer || !HasSavedCam2D) return;
  auto cam = Renderer->GetActiveCamera();
  if(!cam) return;
  cam->SetPosition(Cam2D_Pos);
  cam->SetFocalPoint(Cam2D_Focal);
  cam->SetViewUp(Cam2D_ViewUp);
  cam->SetClippingRange(Cam2D_Clipping);
  cam->SetParallelScale(Cam2D_ParallelScale);
}

void ModeToggleCallback::Setup3DCamera(){}

void ModeToggleCallback::Execute(vtkObject*, unsigned long eventId, void*){
  if(eventId != vtkCommand::LeftButtonPressEvent) return;
  if(!Iren || !Renderer || !ButtonText || !Style2D || !Style3D) return;

  int* pos = Iren->GetEventPosition();
  int x = pos[0], y = pos[1];
  if(x < BtnX0 || x > BtnX1 || y < BtnY0 || y > BtnY1) return;

  Is3D = !Is3D;

  if(Is3D){
    Save2DCamera();
    Iren->SetInteractorStyle(Style3D);
    ButtonText->SetInput("[ 3D MODE ]");
    SetPropsVisible(Props2D,false);
    SetPropsVisible(Props3D,true);
    Setup3DCamera();
  }else{
    Iren->SetInteractorStyle(Style2D);
    ButtonText->SetInput("[ 2D MODE ]");
    SetPropsVisible(Props2D,true);
    SetPropsVisible(Props3D,true);
    Restore2DCamera();
  }

  Iren->GetRenderWindow()->Render();
  this->AbortFlagOn();
}
