// cb_mode_toggle.h
#pragma once
#include <vtkCommand.h>
#include <vtkSmartPointer.h>
#include <vector>

class vtkProp;
class vtkRenderer;
class vtkRenderWindowInteractor;
class vtkTextActor;
class vtkInteractorStyle;

class ModeToggleCallback : public vtkCommand {
public:
  static ModeToggleCallback* New();
  vtkTypeMacro(ModeToggleCallback, vtkCommand);

  vtkRenderWindowInteractor* Iren = nullptr;
  vtkRenderer* Renderer = nullptr;
  vtkTextActor* ButtonText = nullptr;

  vtkInteractorStyle* Style2D = nullptr;
  vtkInteractorStyle* Style3D = nullptr;

  bool Is3D = true;
  bool HasSavedCam2D = false;

  // 你原来按钮矩形
  int BtnX0=0, BtnY0=0, BtnX1=0, BtnY1=0;

  void Add2DProp(vtkProp* p);
  void Add3DProp(vtkProp* p);

  void Execute(vtkObject* caller, unsigned long eventId, void* callData) override;

private:
  std::vector<vtkProp*> Props2D;
  std::vector<vtkProp*> Props3D;

  double Cam2D_Pos[3]{}, Cam2D_Focal[3]{}, Cam2D_ViewUp[3]{};
  double Cam2D_Clipping[2]{};
  double Cam2D_ParallelScale = 1.0;

  void SetPropsVisible(const std::vector<vtkProp*>& props, bool vis);
  void Save2DCamera();
  void Restore2DCamera();
  void Setup3DCamera();
};
