file(REMOVE_RECURSE
  "CMakeFiles/overlay_viewer_brother.dir/cb_camera_lock_key.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/cb_camera_lock_key.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/cb_fracture_box_select.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/cb_fracture_box_select.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/cb_fracture_pick.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/cb_fracture_pick.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/cb_mouse_move_coord.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/cb_mouse_move_coord.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/data.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/data.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/fracture_select_effect.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/fracture_select_effect.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/home/jy/projects/combined_visualization/shared.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/home/jy/projects/combined_visualization/shared.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/main_brother.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/main_brother.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/style_lockable.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/style_lockable.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/ui_helpers.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/ui_helpers.cpp.o.d"
  "CMakeFiles/overlay_viewer_brother.dir/vtk_utils.cpp.o"
  "CMakeFiles/overlay_viewer_brother.dir/vtk_utils.cpp.o.d"
  "overlay_viewer_brother"
  "overlay_viewer_brother.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/overlay_viewer_brother.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
